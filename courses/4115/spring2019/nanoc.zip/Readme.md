### Build the nanoc compiler

```
ocamlbuild -pkgs llvm nanoc.native
```

### Run the nanoc compiler and generate llvm code
```
./nanoc.native -l example.mc
```

### Run the llvm code
```
lli example.out
```

### Compiler files
-  `ast.ml`: abstract syntax tree (AST) definition
-  `scanner.mll`: scanner
-  `nanocparse.mly`: parser
-  `sast.ml`: definition of the semantically-checked AST
-  `semant.ml`: semantic checking
-  `irgen.ml`: LLVM IR code generator

### Other files

- `test1.ml`: the file to test the scanner and parser
- `test2.ml`: the file to test the semantic checker
- `nanoc.ml`: top-level file to test and run nanoc compiler
- `example.mc`: a sample nanoc source code
- `example.out`: a sample compiled code of example.mc
