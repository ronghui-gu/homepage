### Build the nanoc compiler

```
ocamlbuild -use-ocamlfind -pkgs llvm,llvm.analysis nanoc.native
```

### Run the nanoc compiler and generate llvm code
```
./nanoc.native -l example.mc
```

### Run the llvm code
```
lli example.out
```

### Testing files

- `test1.ml` is the file to test the scanner and parser
- `test2.ml` is the file to test the semantic checker
